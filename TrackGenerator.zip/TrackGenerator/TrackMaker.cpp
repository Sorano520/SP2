#include "TrackMaker.h"

TrackMaker::TrackMaker()
{
	MapInfo = nullptr;
	Position = nullptr;
	NumofPiece = 0;
};

TrackMaker::~TrackMaker()
{
	delete[] MapInfo;
	delete[] Position;
	MapInfo = nullptr;
	Position = nullptr;
};

void TrackMaker::Init(string FileDirectory)
{
	fstream File(FileDirectory);
	string test;
	if (!File.is_open())
	{
		cout << "Map File not found" << endl;
	}
	while (getline(File, test))
	{
		NumofPiece++;
	}
	MapInfo = new string[NumofPiece];
	Position = new Vector3[NumofPiece];
	NumofPiece = 0; 
	File.clear();
	File.seekg(0, ios::beg);
	while (!File.eof())
	{
		string temp;
		getline(File, temp);
		MapInfo[NumofPiece] = temp;
		NumofPiece++;
	}
	File.close();
	for (int Num = 0; Num < NumofPiece; Num++)
	{
		string temp[3];
		int Index = 0;
		for (int x = 3; x < (int)MapInfo[Num].size(); x++)
		{
			if (MapInfo[Num][x] != ' ')
			{
				temp[Index] += MapInfo[Num][x];
			}
			else if (Index >= 3)
			{
				break;
			}
			else
			{
				Index++;
			}
		}
		Position[Num].x = stoi(temp[0]);
		Position[Num].y = stoi(temp[1]);
		Position[Num].z = stoi(temp[2]);
	}
	cout << endl;
};

int TrackMaker::getNumofPiece()
{
	return NumofPiece;
};

Vector3* TrackMaker::getPosition()
{
	return Position;
};

string* TrackMaker::getMapInfo()
{
	return MapInfo;
};