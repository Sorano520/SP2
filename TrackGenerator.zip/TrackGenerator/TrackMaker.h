#ifndef TRACKMAKER_H
#define TRACKMAKER_H

#include <string>
#include <fstream>
#include <iostream>
#include "Vector3.h"

using namespace std;

class TrackMaker
{
public:
	TrackMaker();
	~TrackMaker();
	void Init(string);
	string* getMapInfo();
	int getNumofPiece();
	Vector3* getPosition();
private:
	string* MapInfo;
	Vector3* Position;
	int NumofPiece;
};

#endif // !TRACKMAKER_H