#pragma once
#include "LapCounter.h"
#include "Application.h"

class Tutorials
{
public:
	Tutorials();
	~Tutorials();
	void SetTrials(LapCounter&);
	bool getTutorialTrails(int);
	bool complete;
private:
	bool TutorialTrails[6];
};