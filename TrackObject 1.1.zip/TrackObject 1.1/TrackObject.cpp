#include "TrackObject.h"

void TrackObject::Init(float X, float Y, float Z)
{
	setPosition(X, Y, Z);
}