#ifndef ITEMOBJECT_H
#define ITEMOBJECT_H

#include "GameObject.h"

class ItemObject : public GameObject
{
public:
	ItemObject();
	void Init(const Vector3& Position);
	void setActive(bool);
	bool getActive();
	float getRotateValue();
private:
	bool Active;
	float RotateValue;
};

#endif // !ITEMOBJECT_H