#include "AIKart.h"

float ni = 0;
float abc = 0;
int tempcheck = 0;

AIKart::AIKart()
{
	SpeedZCoefficientDown = 1;
}

AIKart::~AIKart()
{

}

void AIKart::Update(double dt)
{
	float SKYBOXSIZE = 500.f;
	float carspeed = 3;
	Vector3 view = (Target - getPosition()).Normalized();
	//Vector3 right = view.Cross(Up);
	static const float CAMERA_SPEED = 0.2f;
	if (getPosition().x <= SKYBOXSIZE / 2 - 1.f && getPosition().x >= -SKYBOXSIZE / 2 + 1.f &&
		getPosition().y <= SKYBOXSIZE / 2 - 1.f && getPosition().y >= -SKYBOXSIZE / 2 + 1.f &&
		getPosition().z <= SKYBOXSIZE / 2 - 1.f && getPosition().z >= -SKYBOXSIZE / 2 + 1.f)
	{
		//SpeedZAxis = 0.5;
		//if (SpeedZAxis > 0)
		//{
		//	SpeedZAxis -= (CAMERA_SPEED * dt) / 5.f;
		//}
		//setPosition(getPosition() + right * SpeedXAxis);
		if (Colliding)
		{
			if (ni >= SpeedZAxis * 50)
			{
				ni = 0;
				Colliding = false;
				tempcheck = LapCheck.getCurrentCheckPoint();
			}
			else
			{
				setPosition(getPosition() + view * SpeedZAxis);
				Target = getPosition() + view;
				tempcheck = LapCheck.getCurrentCheckPoint();
				ni++;
			}
		}
		else
		{
			float dist = sqrt(pow(getPosition().x - LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].Center.x, 2) +
				pow(getPosition().z - LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].Center.z, 2));
			Vector3 direction = LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].Center - getPosition();
			if (abc >= 0.5)
			{
				/*if (LapCheck.getCurrentCheckPoint() == tempcheck)
				{
					tempcheck = LapCheck.getCurrentCheckPoint();
				}
				cout << "X: " <<direction.x << " Z:" << direction.z << endl;
				abc = 0;*/
				if (getPosition().x <= LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].RangeX[0] && getPosition().x >= LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].RangeX[1]
					&& getPosition().z <= LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].RangeZ[0] && getPosition().z >= LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].RangeZ[1])
				{

				}
				else
				{
					if (LapCheck.getCurrentCheckPoint() >= LapCounter::getTotalCheckPoint())
					{
						LapCheck.setCurrentCheckPoint(0);
					}
					else
					{
						LapCheck.addCurrentCheckPoint(1);
					}
				}
				abc = 0;
			}
			else
			{
				abc += dt;
			}
			Vector3 Projection;

			Projection.Set(1, 0, 1);
			Mtx44 Rotating;
			Rotating.SetToRotation(LapCheck.getRange()[LapCheck.getCurrentCheckPoint()].RotateValue, 0, 1, 0);

			Projection = Rotating * Projection;

			Vector3 Offset;
			Offset.Set(Move, 0, 0);
			Offset = Rotating * Offset;
			Offset.Normalize();

			/*RotateValue = Math::RadianToDegree(asin(idk.Length() / (Target.Length() * direction.Length())));*/
			RotateValue = LapCheck.getRange()[LapCheck.getCurrentCheckPoint()].RotateValue;
			SpeedZAxis = DefaultSpeedZAxis * SpeedZCoefficientDown;
			//addPosition(Offset);
			addPosition(((direction.Dot(Projection) / direction.LengthSquared())* direction) * SpeedZAxis);
			Target = getPosition() + direction;
		}
	}
	else
	{
		Reset();
	}
}

int AIKart::CheckCar()
{
	switch (LapCheck.getCurrentLap())
	{
	case 1:
		LapCheck.setIndividualTotalCheckPoint(LapCounter::getCheckPointLap(0));
		break;
	case 2:
		/*LapCheck.setTotalCheckPoint(LapCounter::getCheckPointLap(1));
		LapCheck.setCurrentCheckPoint(LapCounter::getCheckPointLap(0));
		break;*/
		LapCheck.setIndividualTotalCheckPoint(LapCounter::getCheckPointLap(1));
		if (LapCheck.getCurrentCheckPoint() >= 5 && LapCheck.getCurrentCheckPoint() <= 10)
		{
			LapCheck.setCurrentCheckPoint(LapCounter::getCheckPointLap(0));
		}
		break;
		/*
		if (LapCheck.getCurrentCheckPoint() >= 4 && LapCheck.getCurrentCheckPoint() <= 10)
		{
			LapCheck.setCurrentCheckPoint(LapCounter::getCheckPointLap(0));
			break;
		}
		else
		{
			break;
		}*/
	case 3:
		LapCheck.setTotalCheckPoint(LapCounter::getCheckPointLap(0));
		break;
		/*
		if (LapCheck.getCurrentCheckPoint() >= 3 && LapCheck.getCurrentCheckPoint() <= 10)
		{
			if (getPosition().x <= LapCheck.getRange()[LapCheck.getCurrentCheckPoint()].Center.x)
			{
				LapCheck.setCurrentCheckPoint(LapCounter::getCheckPointLap(0) + 1);
				LapCheck.setTotalCheckPoint(LapCounter::getCheckPointLap(1));
			}
			else
			{
				LapCheck.setCurrentCheckPoint(4);
				LapCheck.setTotalCheckPoint(LapCounter::getCheckPointLap(0));
			}
		}*/
	}
	//LapCheck.setTotalCheckPoint(LapCounter::getCheckPointLap(1));
	if (SpeedZCoefficientDown != 0)
	{
		if (getPosition().x <= LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].RangeX[0] && getPosition().x >= LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].RangeX[1]
			&& getPosition().z <= LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].RangeZ[0] && getPosition().z >= LapCounter::getRange()[LapCheck.getCurrentCheckPoint()].RangeZ[1])
		{
			LapCheck.addCurrentCheckPoint(1);
			if (LapCheck.getCurrentCheckPoint() >= LapCheck.getIndividualTotalCheckPoint())
			{
				LapCheck.setCurrentCheckPoint(0);
				LapCheck.addCurrentLap();
			}
			if (LapCheck.getCurrentLap() == LapCheck.getLapNumber())
			{
				std::cout << "U finish the game." << std::endl;
			}
		}
	}
	return LapCheck.getCurrentLap();
}

void AIKart::ReduceSpeedCar()
{
	SpeedZCoefficientDown = 0.5;
}

void AIKart::StopSpeedCar()
{
  	SpeedZCoefficientDown = 0;
}

void AIKart::RegainSpeedCar()
{
	SpeedZCoefficientDown = 1;
}