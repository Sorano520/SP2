#include "Range.h"

Range::Range()
{
	RangeX[0] = 0.f;
	RangeX[1] = 0.f;
	RangeZ[0] = 0.f;
	RangeZ[1] = 0.f;
	RotateValue = 0.f;
	Center.Set(0, 0, 0);
}

Range::~Range()
{
}