#include "ItemObject.h"

ItemObject::ItemObject()
{
	Active = true;
	RotateValue = 0;
}

void ItemObject::Init(const Vector3& Position)
{
	setPosition(Position);
}

bool ItemObject::getActive()
{
	return Active;
}

float ItemObject::getRotateValue()
{
	return RotateValue;
}

void ItemObject::setActive(bool TF)
{
	Active = TF;
}