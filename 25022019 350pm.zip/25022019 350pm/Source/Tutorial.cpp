#include "Tutorial.h"
#include "SceneStadium.h"
#include "TrackMaker.h"

Tutorials::Tutorials()
{
	complete = false;
	for (size_t i = 0; i < 6; i++)
	{
		TutorialTrails[i] = false;
	}
};

Tutorials::~Tutorials()
{
};

void Tutorials::SetTrials(LapCounter& Trials)
{
	if (!complete)
	{
		TutorialTrails[0] = true;
		Trials.setIndividualTotalCheckPoint(LapCounter::getTotalCheckPoint());
	}
	if (Trials.getCurrentCheckPoint() >= 4 && TutorialTrails[0])
	{
		TutorialTrails[1] = true;
	}
	if (Trials.getCurrentCheckPoint() >= 28 && TutorialTrails[1])
	{
		TutorialTrails[2] = true;
	}
	if (Trials.getCurrentCheckPoint() >= 40 && TutorialTrails[2])
	{
		if (Application::IsKeyPressed(VK_SPACE))
		{
			TutorialTrails[3] = true;
		}
	}
	if (Trials.getCurrentLap() >= Trials.getLapNumber())
	{
		TutorialTrails[4] = true;
	}
	if (TutorialTrails[4] && Application::IsKeyPressed('T'))
	{
		TutorialTrails[5] = true;
		TutorialTrails[0] = false;
		complete = true;
	}
}

bool Tutorials::getTutorialTrails(int Index)
{
	return TutorialTrails[Index];
}