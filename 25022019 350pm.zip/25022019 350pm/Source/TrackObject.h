#ifndef TRACKOBJECT_H
#define TRACKOBJECT_H

#include "GameObject.h"

class TrackObject : public GameObject
{
public:
	void Init(const Vector3&);
};


#endif