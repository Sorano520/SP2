#pragma once

#ifndef PLAYER_H
#define PLAYER_H

#include "Vehicle.h"
#include "Tutorial.h"


class Player : public Vehicle
{
public:
	Player();
	~Player();
	void Update(double);
	//Tutorials getTry();
private:
	bool Examples[5];
	bool ComTut;
	//Tutorials Try;
};

#endif // !AIKART_H