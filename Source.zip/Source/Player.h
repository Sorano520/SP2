#ifndef PLAYER_H
#define PLAYER_H

#include "Vehicle.h"

class Player : public Vehicle
{
public:
	void Update(double);
};

#endif // !AIKART_H