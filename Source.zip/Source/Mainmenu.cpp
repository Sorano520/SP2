#include "Mainmenu.h"
#include <windows.h>
#include <mmsystem.h>

Console console(90, 21, "Mainmenu");

Mainmenu::Mainmenu()
{
	openmainmenu = true;
}

Mainmenu::~Mainmenu()
{

}

bool Mainmenu::IsKeyPressed(unsigned short key)
{
	return ((GetAsyncKeyState(key) & 0x8001) != 0);
}

void Mainmenu::init(void)
{
	//Console console(90, 21, "Mainmenu");
	SGameChar Char;
	////g_dBounceTime = ElapsedTime + 0.125;
	//// Set precision for floating point output
	//ElapsedTime = 0.0;
	//g_dBounceTime = 0.0;

	//// sets the initial state for the game
	//g_eGameState = S_SPLASHSCREEN;

	//// sets the width, height and the font name to use in the console
	console.setConsoleFont(0, 16, L"Consolas");
	COORD c;
	c.X = 0;
	c.Y = 0;
	console.writeToBuffer(c, "hi");
	Char.pointer.X = 31;
	Char.pointer.Y = 10;
	Char.mainmenu = false;
	PlaySound(TEXT("Music/song2Delete.wav"), NULL, SND_ASYNC | SND_LOOP);
}
void Mainmenu::shutdown(void)
{
	colour(FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED);

	console.clearBuffer();

	
	//Reset before exiting the program
		//            Do your clean up of memory here
}
void Mainmenu::update(double dt)
{
	// get the delta time
	ElapsedTime += dt;
	DeltaTime = dt;
	switch (g_eGameState)
	{
	case S_SPLASHSCREEN: splashScreenWait(); // game logic for the splash screen
		break;
	case S_GAME: gameplay(); // gameplay logic when we are in the game
		break;
	}
}

void Mainmenu::loadscreen()
{
	COORD c;
	c.X = 0;
	c.Y = 0;
	console.writeToBuffer(c, "hi");
	clearScreen();      // clears the current screen and draw from scratch 
	switch (g_eGameState)
	{
	case S_SPLASHSCREEN: renderSplashScreen();
		break;
	case S_GAME: renderGame();
		break;
	}

	renderToScreen();   // dump the contents of the buffer to the screen, one frame worth of game
}

void Mainmenu::splashScreenWait()    // waits for time to pass in splash screen
{
	g_eGameState = S_GAME;
}

void Mainmenu::gameplay()            // gameplay logic
{

	processUserInput(); // checks if you should change states or do something else with the game, e.g. pause, exit
						// sound can be played here too.
}


//loading of character location
void Mainmenu::renderCharacter()
{
	// Draw the location of the character
	WORD charColor = 0x0C;
	//if (Char.m_bActive)
	//{
	//	charColor = 0x0A;
	//}
	//console.writeToBuffer(Char.character, (char)1, charColor);
}
////loading of frame
//void renderFramerate()
//{
//	COORD c;
//	// displays the framerate
//	std::ostringstream ss;
//	ss << std::fixed << std::setprecision(3);
//	ss << 1.0 / DeltaTime << "fps";
//	c.X = console.getConsoleSize().X - 9;
//	c.Y = 0;
//	console.writeToBuffer(c, ss.str());
//
//	// displays the elapsed time
//	ss.str("");
//	ss << ElapsedTime << "secs";
//	c.X = 0;
//	c.Y = 0;
//	console.writeToBuffer(c, ss.str(), 0x59);
//}

void Mainmenu::renderToScreen()
{
	// Writes the buffer to the console, hence you will see what you have written
	console.flushBufferToConsole();
}
//cls
void Mainmenu::clearScreen()
{
	// Clears the buffer with this colour attribute
	console.clearBuffer(0x00);
}
// renders the starting  screen
void Mainmenu::renderSplashScreen()
{
	renderGame();
}

//loading of event / D map
void Mainmenu::renderGame()
{
	COORD c;
	c.X = 0;
	c.Y = 0;
	console.writeToBuffer(c, "hi");
}
//esc button
void Mainmenu::processUserInput()
{
	// quits the game if player hits the escape key
	if (IsKeyPressed(VK_ESCAPE))
	{
		openmainmenu = false;
		shutdown();
	}
}

bool Mainmenu::menu()
{
	while(1)
	return openmainmenu;
}