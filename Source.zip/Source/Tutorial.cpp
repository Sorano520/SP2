#include "Tutorial.h"
#include "SceneStadium.h"
#include "TrackMaker.h"

Tutorials::Tutorials()
{
	complete = true;
	for (size_t i = 0; i < 5; i++)
	{
		TutorialTrails[i] = false;
	}
};

Tutorials::~Tutorials()
{
};

void Tutorials::SetTrials(LapCounter& Trials)
{
	if (complete == false)
	{
		TutorialTrails[0] = true;
	}
	if (Trials.getCurrentCheckPoint() >= 4 && TutorialTrails[0] == true)
	{
		TutorialTrails[1] = true;
	}
	if (Trials.getCurrentCheckPoint() >= 28 && TutorialTrails[1] == true)
	{
		TutorialTrails[2] = true;
	}
	if (Trials.getCurrentCheckPoint() >= 40 && TutorialTrails[2] == true)
	{
		if (Application::IsKeyPressed(VK_SPACE))
		{
			TutorialTrails[3] = true;
		}
	}

}

bool Tutorials::getTutorialTrails(int Index)
{
	return TutorialTrails[Index];
}