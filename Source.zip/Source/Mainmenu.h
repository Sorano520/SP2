#pragma once
#ifndef _GAME_H
#define _GAME_H

#include "timer.h"
#include "console.h"
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>

using namespace std;

class Mainmenu
{
public:
	// Enumeration to store the control keys that your game will have
	enum EKEYS
	{
		K_UP,
		K_DOWN,
		K_LEFT,
		K_RIGHT,
		K_ESCAPE,
		K_SPACE,
		K_JUMP,
		K_RETURN,
		//everything above count
		K_COUNT,
	};

	// Enumeration for the different screen states
	enum EGAMESTATES
	{
		S_SPLASHSCREEN,
		S_GAME,
		S_COUNT
	};

	struct SGameChar
	{
		COORD character;
		COORD pointer;
		bool  m_bActive;
		bool mainmenu;
	};

	Mainmenu();
	~Mainmenu();
	void init(void);      // initialize your variables, allocate memory, etc
	void update(double dt); // update the game and the state of the game
	void loadscreen(void);      // renders the current state of the game to the console
	void shutdown(void);      // do clean up, free memory

	void splashScreenWait();    // waits for time to pass in splash screen
	void gameplay();            // gameplay logic
	void processUserInput();    // checks if you should change states or do something else with the game, e.g. pause, exit
	void clearScreen();         // clears the current screen and draw from scratch 
	void renderSplashScreen();  // renders the splash screen
	void renderGame();          // renders the game stuff
	void renderMap();           // renders the map to the buffer first
	void renderCharacter();     // renders the character into the buffer
	void renderToScreen();      // dump the contents of the buffer to the screen, one frame worth of game

	double  ElapsedTime;
	double  DeltaTime;
	EGAMESTATES g_eGameState = S_SPLASHSCREEN;
	double  g_dBounceTime; // this is to prevent key bouncing, so we won't trigger keypresses more than once
						   // Console object
	bool IsKeyPressed(unsigned short );

	bool openmainmenu;

	bool menu();
};
#endif // _GAME_H