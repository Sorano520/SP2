#pragma once
#include <vector>
#include <string>

using namespace std;

class Music
{
	
};