#include "AIKart.h"

void AIKart::Update(double dt)
{
	float SKYBOXSIZE = 1500.f;
	float carspeed = 3;
	Vector3 view = (Target - getPosition()).Normalized();
	Vector3 right = view.Cross(Up);
	static const float CAMERA_SPEED = 0.2f;
	if (getPosition().x <= SKYBOXSIZE / 2 - 1.f && getPosition().x >= -SKYBOXSIZE / 2 + 1.f &&
		getPosition().y <= SKYBOXSIZE / 2 - 1.f && getPosition().y >= -SKYBOXSIZE / 2 + 1.f &&
		getPosition().z <= SKYBOXSIZE / 2 - 1.f && getPosition().z >= -SKYBOXSIZE / 2 + 1.f)
	{
		if (SpeedZAxis > 0)
		{
			SpeedZAxis -= (CAMERA_SPEED * dt) / 5.f;
		}
		setPosition(getPosition() + right * SpeedXAxis);
		setPosition(getPosition() + view * SpeedZAxis);
		Target = getPosition() + view;
	}
	else
	{
		Reset();
	}
}