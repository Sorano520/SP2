

#include "Mainmenu.h"
#include "Application.h"

int main( void )
{
	bool mainmenu = true;
	Mainmenu menu;
	Application app;

	//cout << "hi";

	menu.init();
	while (mainmenu == true)
	{
		menu.update(1);   // update the game
		menu.loadscreen();
		mainmenu = menu.menu();
	}

	system("CLS");
	if(mainmenu==false)
	{
		app.Init();
		app.Run();
		app.Exit();
	}
}