#include "Environment.h"

void Environment::Init(const Vector3& Position)
{
	setPosition(Position);
}