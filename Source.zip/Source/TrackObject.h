#pragma once
#ifndef TRACKOBJECT_H
#define TRACKOBJECT_H

#include "GameObject.h"

class TrackObject : public GameObject
{
public:
	void Init(float, float, float);
};


#endif