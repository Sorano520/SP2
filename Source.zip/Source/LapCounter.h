#pragma once
#include "Vehicle.h"
#include "Range.h"
#include "TrackMaker.h"

class LapCounter
{
public:
	LapCounter();
	~LapCounter();
	void SetLapCounter(int x);
	int CheckCar(Vehicle&);
	void SetRange(TrackMaker&);

	int lapCounter;
	int LapNumber;
	int FinalLap;
	int TotalCheckPoint;
	int CurrentCheckPoint;
	int CheckPointNumber;
	Range* CheckPoint;

private:
};