#pragma once

class Range
{
public:
	Range();
	~Range();
	float RangeX[2];
	float RangeZ[2];
};