#include "TrackObject.h"

void TrackObject::Init(const Vector3& Position)
{
	setPosition(Position);
}