#ifndef LAPCOUNTER_H
#define LAPCOUNTER_H

#include "Range.h"
#include "TrackMaker.h"

class LapCounter
{
public:
	LapCounter();
	~LapCounter();

	int getCurrentLap();
	int getCurrentCheckPoint();
	int getIndividualTotalCheckPoint();

	void setCurrentCheckPoint(int);
	void setTotalCheckPoint(int);
	void setIndividualTotalCheckPoint(int);
	void addCurrentCheckPoint(int);
	void addCurrentLap();
	void setCurrentLap(int);

	static void SetRange(TrackMaker&);
	static int getLapNumber();
	static int getTotalCheckPoint();
	static Range* getRange();
	static int getCheckPointLap(int);

private:
	int CurrentLap;
	int CurrentCheckPoint;
	int IndividualTotalCheckPoint;

	static int LapNumber;
	static int TotalCheckPoint;
	static Range* CheckPoint;
	static int Lap[2];
};

#endif // !LAPCOUNTER_H