//#ifndef VARIABLE_H
//#define VARIABLE_H
//
//bool Increase = true;
//double move = 0.10;
//const float pi = 3.14159;
//bool colorIncrease;
//float colorChange;
//
//#endif 

