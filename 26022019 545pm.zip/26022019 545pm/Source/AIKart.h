#ifndef AIKART_H
#define AIKART_H

#include "Vehicle.h"

class AIKart : public Vehicle
{
public:
	AIKart();
	~AIKart();
	int CheckCar();
	void Update(double);
	static void ReduceSpeedCar();
	static void StopSpeedCar();
	static void RegainSpeedCar();
private:
	/*float TimeUpdate;
	float TimeUpdate2nd;
	int tempcheck;*/
};

#endif // !AIKART_H