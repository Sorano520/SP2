#ifndef PLAYER_H
#define PLAYER_H

#include "Vehicle.h"

class Player : public Vehicle
{
public:
	Player();
	int CheckCar();
	void Update(double);
private:
	bool Tutorial[10];
};

#endif // !AIKART_H