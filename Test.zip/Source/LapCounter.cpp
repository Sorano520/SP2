#include "LapCounter.h"
#include "Vehicle.h"

LapCounter::LapCounter()
{
	lapCounter = 0;
	FinalLap = 4;
	TotalCheckPoint = 0;
	LapNumber = 3;
	CurrentCheckPoint = 1;
	//CheckPoint = new Range[TotalCheckPoint];
	//CheckPoint[0].RangeX[0] = -5;// +xcoord[0] -> left from the centre
	//CheckPoint[0].RangeX[0] = 5;// +xcoord[1]  -> right from the centre
	//CheckPoint[0].RangeZ[0] = -2;
	//CheckPoint[0].RangeZ[0] = 2;

}

LapCounter::~LapCounter()
{
}

void LapCounter::SetLapCounter(int x)
{
	lapCounter = x;
}

int LapCounter::CheckCar(Vehicle& Car)
{
	switch (LapNumber)
	{
	case 1:
		if (LapNumber == 1)
		{
			TotalCheckPoint = 38;
			break;
		}
		else
		{
			break;
		}
	case 2:
		TotalCheckPoint = 78;
		if (CurrentCheckPoint == 4)
		{
			CurrentCheckPoint = 38;
			break;
		}
		else
		{
			break;
		}
	case 3:
		if (CurrentCheckPoint == 3)
		{
			if (Car.getPosition().x <= CheckPoint[3].Centre.x)
			{
				CurrentCheckPoint = 39;
				TotalCheckPoint = 78;
			}
			else
			{
				CurrentCheckPoint = 4;
				TotalCheckPoint = 38;
			}
		}
	}
	if (Car.getPosition().x <= CheckPoint[CurrentCheckPoint].RangeX[0] && Car.getPosition().x >= CheckPoint[CurrentCheckPoint].RangeX[1]
		&& Car.getPosition().z <= CheckPoint[CurrentCheckPoint].RangeZ[0] && Car.getPosition().z >= CheckPoint[CurrentCheckPoint].RangeZ[1])
	{
		CurrentCheckPoint++;
		if (CurrentCheckPoint == TotalCheckPoint)
		{
			CurrentCheckPoint = 0;
			LapNumber++;
		}
		if (LapNumber == FinalLap)
		{
			std::cout << "U finish the game." << std::endl;
		}
	}
	return LapNumber;
}

void LapCounter::SetRange(TrackMaker& Check)
{
	TotalCheckPoint = Check.getNumofPiece();
	CheckPoint = new Range[TotalCheckPoint];
	for (int i = 0; i < TotalCheckPoint; i++)
	{
		CheckPoint[i].Centre = Check.getTrackObject()[i].getPosition();
		CheckPoint[i].RangeX[0] = Check.getTrackObject()[i].getPosition().x + Check.getTrackObject()[i].getXDist();
		CheckPoint[i].RangeX[1] = Check.getTrackObject()[i].getPosition().x - Check.getTrackObject()[i].getXDist();
		CheckPoint[i].RangeZ[0] = Check.getTrackObject()[i].getPosition().z + Check.getTrackObject()[i].getZDist();
		CheckPoint[i].RangeZ[1] = Check.getTrackObject()[i].getPosition().z - Check.getTrackObject()[i].getZDist();
		cout << "LAP CHECK" << endl;
		cout << "Index " << i << endl;
		cout << "X0: " << CheckPoint[i].RangeX[0] << " X1: " << CheckPoint[i].RangeX[1] << endl;
		cout << "Z0: " << CheckPoint[i].RangeZ[0] << " Z1: " << CheckPoint[i].RangeZ[1] << endl;
	}
}





