#ifndef AIKART_H
#define AIKART_H

#include "Vehicle.h"

class AIKart : public Vehicle
{
public:
	void Update(double);
};

#endif // !AIKART_H