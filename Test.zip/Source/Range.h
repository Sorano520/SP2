#pragma once
#include "Vector3.h"

class Range
{
public:
	Range();
	~Range();
	float RangeX[2];
	float RangeZ[2];
	Vector3 Centre;
};