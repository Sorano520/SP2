#include "Range.h"

Range::Range()
{
}

Range::~Range()
{
}