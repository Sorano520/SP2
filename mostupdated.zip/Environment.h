#ifndef ENVIRONMENT_H
#define ENVIRONMENT_H

#include "GameObject.h"

class Environment : public GameObject
{
public:
	void Init(const Vector3& Position);
private:
};


#endif